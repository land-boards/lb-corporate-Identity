#!/bin/bash

indent -linux -l150 youyue858d.ino
indent -linux -l150 youyue858d.h

