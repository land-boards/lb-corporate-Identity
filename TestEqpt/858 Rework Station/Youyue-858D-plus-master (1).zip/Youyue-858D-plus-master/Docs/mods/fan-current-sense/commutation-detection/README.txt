
Please have a look at this repository for a working prototype:

https://github.com/madworm/Youyue-858D-plus-FAN-speed-mod

